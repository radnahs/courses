package com.sellingportal.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.sellingportal.beans.UserBean;
import com.sellingportal.db.DBConnectionMySQL;

public class UsersService {
	
	public List<UserBean> fetchAllUsers() {
		DBConnectionMySQL exec = new DBConnectionMySQL();
		List<UserBean> lstUsrBean = new ArrayList<>();
		String query = "select * from users";
		try {
			ResultSet rs = exec.fetchResultsFromQuery(query);
			while (rs.next()) {
				UserBean userBean = new UserBean();
				userBean.setId(rs.getInt("id"));
				userBean.setFirstname(rs.getString("firstname"));
				userBean.setLastname(rs.getString("lastname"));
				userBean.setUsername(rs.getString("username"));
				userBean.setPassword(rs.getString("password"));
				userBean.setEmail(rs.getString("email"));
				userBean.setPhone(rs.getString("phone"));
				lstUsrBean.add(userBean);
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return lstUsrBean;
	}

	public String create() {
		
		return "";
	}

}
