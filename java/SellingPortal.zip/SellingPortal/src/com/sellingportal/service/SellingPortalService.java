package com.sellingportal.service;

import java.util.List;

import com.sellingportal.beans.UserBean;

public class SellingPortalService {
	
	public List<UserBean> fetchUsers() {
		UsersService exec = new UsersService();
		List<UserBean> lstUsrBean = exec.fetchAllUsers();
		return lstUsrBean;
	}
	
	public void createUser(UserBean userBean) {
		UsersService exec = new UsersService();
		List<UserBean> lstUsrBean = exec.fetchAllUsers();
				
	}
	

}
