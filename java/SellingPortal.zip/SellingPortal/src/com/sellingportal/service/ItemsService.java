package com.sellingportal.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.sellingportal.beans.ItemBean;
import com.sellingportal.db.DBConnectionMySQL;

public class ItemsService {
	
	public List<ItemBean> fetchAllItems() {
		DBConnectionMySQL exec = new DBConnectionMySQL();
		List<ItemBean> lstItmBean = new ArrayList<>();
		String query = "select * from items";
		try {
			ResultSet rs = exec.executeQuery(query);
			while (rs.next()) {
				ItemBean itmBean = new ItemBean();
				itmBean.setId(rs.getInt("id"));
				itmBean.setName(rs.getString("name"));
				lstItmBean.add(itmBean);
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return lstItmBean;
	}

}
