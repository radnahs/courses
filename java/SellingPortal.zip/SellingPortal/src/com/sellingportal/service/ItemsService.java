package com.sellingportal.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.sellingportal.beans.ItemBean;
import com.sellingportal.db.DBConnectionMySQL;

public class ItemsService {
	
	public List<ItemBean> fetchAllItems() {
		DBConnectionMySQL exec = new DBConnectionMySQL();
		List<ItemBean> lstItmBean = new ArrayList<>();
		String query = "select * from items";
		try {
			ResultSet rs = exec.fetchResultsFromQuery(query);
			while (rs.next()) {
				ItemBean itmBean = new ItemBean();
				itmBean.setId(rs.getInt("id"));
				itmBean.setName(rs.getString("name"));
				itmBean.setManufacturer(rs.getString("manufacturer"));
				itmBean.setPrice(rs.getString("price"));
				lstItmBean.add(itmBean);
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return lstItmBean;
	}
	
	public int addItem(ItemBean itmBn) {
		DBConnectionMySQL exec = new DBConnectionMySQL();
		String query = "INSERT INTO Items ( name, categoryid, manufacturer, price,weight,length,width,height) "
				+ "values ('"+itmBn.getName()+"','10','"+itmBn.getManufacturer()+"','"+itmBn.getPrice()+"','100','12','11','33')";
		int rs=0;
		rs = exec.addFromQuery(query);
		return rs;
	}

}
