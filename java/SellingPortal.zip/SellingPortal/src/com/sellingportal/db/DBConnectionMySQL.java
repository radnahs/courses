package com.sellingportal.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnectionMySQL {

	public ResultSet executeQuery(String query) {
		ResultSet rs= null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(("jdbc:mysql://localhost:3306/sellingportal"), "root", "");
			Statement stmt = con.createStatement();
		    rs = stmt.executeQuery(query);

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}

}
