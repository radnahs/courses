package com.sellingportal.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnectionMySQL {

	private Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(("jdbc:mysql://localhost:3306/sellingportal"), "root", "");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}

	public ResultSet fetchResultsFromQuery(String query) {
		ResultSet rs = null;
		try {
			Connection con = getConnection();
			Statement stmt = con.createStatement();
			rs = stmt.executeQuery(query);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}

	public int addFromQuery(String query) {
		int rs=0;
		try {
			Connection con = getConnection();
			Statement stmt = con.createStatement();
			rs = stmt.executeUpdate(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}
}
