package com.sellingportal.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sellingportal.beans.UserBean;
import com.sellingportal.service.UsersService;

/**
 * Servlet implementation class UserController
 */
@WebServlet("/UserPortal")
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public UserController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UsersService usersService = new UsersService();
		List<UserBean> lstUsrBean = usersService.fetchAllUsers();
		request.setAttribute("lstUserBean", lstUsrBean);
		RequestDispatcher rd = request.getRequestDispatcher("ui/users.jsp");
		rd.forward(request, response);

	}

}
