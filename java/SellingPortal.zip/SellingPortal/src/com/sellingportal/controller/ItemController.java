package com.sellingportal.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ItemController
 */
@WebServlet("/ItemPortal")
public class ItemController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ItemController() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String typeOfRequest = request.getParameter("typeOfRequest");
		if("ADD".equals(typeOfRequest)) {
			addItem(request,response);
		}
		showItems(request,response);
	}
	
	private void showItems(HttpServletRequest request, HttpServletResponse response) {
		
	}
	
	private void addItem(HttpServletRequest request, HttpServletResponse response) {
		
	}

}
