package com.sellingportal.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sellingportal.beans.ItemBean;
import com.sellingportal.service.ItemsService;

/**
 * Servlet implementation class ItemController
 */
@WebServlet("/ItemPortal")
public class ItemController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ItemController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String typeOfRequest = request.getParameter("typeOfRequest");
		if("ADD".equals(typeOfRequest)) {
			addItem(request,response);
		}
		showItems(request,response);
	}
	
	private void showItems(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException {
		ItemsService itemsService = new ItemsService();
		List<ItemBean> lstItems= itemsService.fetchAllItems();
		request.setAttribute("lstItems", lstItems);
		RequestDispatcher rd = request.getRequestDispatcher("ui/items.jsp");
		rd.forward(request, response);
	}
	
	private void addItem(HttpServletRequest request, HttpServletResponse response) {
		ItemsService itemsService = new ItemsService();
		ItemBean itmBn = new ItemBean();
		itmBn.setName(request.getParameter("item_name"));
		itmBn.setManufacturer(request.getParameter("item_manufacturer"));
		itmBn.setPrice(request.getParameter("item_price"));
		itmBn.setColor(request.getParameter("item_color"));
		itemsService.addItem(itmBn);
	}

}
