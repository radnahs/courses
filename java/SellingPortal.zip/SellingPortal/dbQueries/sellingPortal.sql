CREATE TABLE Users (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
firstname VARCHAR(30) NOT NULL,
lastname VARCHAR(30) NOT NULL,
username VARCHAR(30) NOT NULL,
password VARCHAR(30) NOT NULL,
address_id int(10) unsigned,
email VARCHAR(50),
phone int(10),
reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)


INSERT INTO users (firstname, lastname, username, password ,email, phone) VALUES 
('Shantanu', 'Sikdar', 'shan', '123123', 'shantanu@example.com', '9423577420' ),
('James', 'Cameroon', 'jamoon', '123123', 'james@example.com', '94235272320' ),
('Piya', 'Sikdar', 'piar', '123123', 'piard@example.com', '9423577411' ),
('Rod', 'Jhonson', 'rodon', '123123', 'rod@example.com', '9423577421' ),
('Josh', 'Bloch', 'joshch', '123123', 'josh@example.com', '9423577420' );

